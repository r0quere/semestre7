# -*- coding: utf-8 -*-
import sys
major=sys.version_info.major
minor=sys.version_info.minor
if major==2 and minor==7 :
    import Tkinter as tk
    import tkFileDialog as filedialog
elif major==3 :
    import tkinter as tk
    from tkinter import filedialog
else :
    if __name__ == "__main__" :
        print("Your python version is : ",major,minor)
        print("... I guess it will work !")
    import tkinter as tk
    from tkinter import filedialog 

from math import pi,sin
from utils import radians
# import logging
# logging.basicConfig(level=logging.DEBUG)
# # logging.basicConfig(level=logging.CRITICAL)
# logger = logging.getLogger(__name__)

class Controller (object):
    mag = 0,5
    harmonics=1
    signal = []
    name = ""
    # canvas = None
    def __init__(self,model,view, parent,mag = 0.5):
        self.parent=parent
        self.model,self.view = model,view
        self.create_controls()
        # self.packing()
        self.mag=mag
        self.packing()
        self.signal = model.signal
        self.name = model.name

    def get_name(self):
        return self.name
    def set_name(self,name):
        self.name=name
    def get_magnitude(self):
        return self.mag
    def set_magnitude(self,mag):
        self.mag=mag
    def get_frequency(self):
        return self.freq
    def set_frequency(self,freq):
        self.freq=freq
    def get_phase(self):
        return self.phase
    def set_phase(self,phase):
        self.phase=phase
    def get_harmonics(self) :
        return self.harmonics    
    def set_harmonics(self,harmonics=1) :
        self.harmonics=harmonics
    def get_samples(self):
        return self.samples
    def set_samples(self,samples):
        self.samples=samples
         
    def delete(self):
        del self.signal[0:]
        self.notify()

    def packing(self) :
       # self.canvas.pack(expand=1,fill="both",padx=6)
        self.scale_mag.pack()
        self.scale_harmonics.pack()
        self.scale_phase.pack()
        self.scale_freq.pack()
   
    def create_controls(self):
        self.phase_var=tk.DoubleVar()
        self.phase_var.set(self.get_magnitude())
        self.scale_phase=tk.Scale(self.parent,variable=self.phase_var,
                          label="Phase",
                          orient="horizontal",length=250,
                          from_=-90,to=90,relief="raised",
                          sliderlength=20,resolution = 0.1,
                          tickinterval=20,
                          command=self.cb_update_phase)

        self.freq_var=tk.DoubleVar()
        self.freq_var.set(self.get_magnitude())
        self.scale_freq=tk.Scale(self.parent,variable=self.freq_var,
                          label="Frequence",
                          orient="horizontal",length=250,
                          from_=0,to=50,relief="raised",
                          sliderlength=20,resolution = 0.1,
                          tickinterval=10,
                          command=self.cb_update_frequency)

        self.mag_var=tk.DoubleVar()
        self.mag_var.set(self.get_magnitude())
        self.scale_mag=tk.Scale(self.parent,variable=self.mag_var,
                          label="Amplitude",
                          orient="horizontal",length=250,
                          from_=0,to=1,relief="raised",
                          sliderlength=20,resolution = 0.1,
                          tickinterval=0.5,
                          command=self.cb_update_magnitude)
        self.harmonics_var=tk.IntVar()
        self.harmonics_var.set(self.get_harmonics())
        self.scale_harmonics=tk.Scale(self.parent,variable=self.harmonics_var,
                          label="Harmonics",
                          orient="horizontal",length=250,
                          from_=1,to=50,relief="raised",
                          sliderlength=20,tickinterval=5,
                          command=self.cb_update_harmonics)
        frame=tk.LabelFrame(self.parent,text="Harmonics")
        self.radio_var=tk.IntVar()
        btn=tk.Radiobutton(frame,text="All", variable=self.radio_var,value=1,command=self.cb_activate_button)
        btn.select()
        btn.pack(anchor ="w")
        btn=tk.Radiobutton(frame,text="Odd", variable=self.radio_var,value=2,command=self.cb_activate_button)
        btn.pack(anchor ="w")
        frame.pack()
        

    def cb_update_magnitude(self,event):
        print("cb_update_magnitude(self,event)",self.mag_var.get())
        self.model.set_magnitude(self.mag_var.get())
        self.model.generate()
        # sself.view.plot_signal(self.signal,self.name)

    def cb_update_phase(self,event):
        print("cb_update_phase(self,event)",self.phase_var.get())
        self.model.set_phase(self.phase_var.get())
        self.model.generate()

    def cb_update_frequency(self,event):
        print("cb_update_frequency(self,event)",self.freq_var.get())
        self.model.set_frequency(self.freq_var.get())
        self.model.generate()

    def cb_update_harmonics(self,event):
        print("cb_update_harmonics(self,event)",self.harmonics_var.get())
        self.model.set_harmonics(self.harmonics_var.get())
        self.model.generate()
        # self.view.plot_signal(self.signal,self.name)

    def cb_activate_button(self):
        print("You selected the option " + str(self.radio_var.get()))
        self.model.harmo_odd_even=self.radio_var.get()